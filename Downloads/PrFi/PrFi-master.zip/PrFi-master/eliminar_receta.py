
#eliminar una receta médica generada a un paciente 
def eliminarRecetaPaciente(a)
    #funcion de imprimir lista de todas las recetas médicas 
    #lista impresa 
    num_folio_para_eliminar = input("Ingrese el número de Folio: ")
    #while num_folio_para_eliminar este dentro de la lista entonces 
    #print dato especifico 
    elimina_confirmacion = input("Desea eliminar la receta registrada? (s/n)")
    if elimina_confirmacion.lower() == "S" :
        #nombrelista.pop(1 <- pocision de dato)
        #y mostrar el listado de recetas que actualmente esten registradas 
        continuar_eliminando = input("Continuar con otra receta médica (s/n)")
        if continuar_eliminado.lower() == "s" :
            #return to mostrar lista para eliminar 
        #else entonces main menu 

    #else main menu